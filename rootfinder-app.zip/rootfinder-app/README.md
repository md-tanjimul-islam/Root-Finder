# Root-Finding Visualizer — Fixed Point Iteration & Newton-Raphson

A Streamlit web app implementing two numerical root-finding algorithms:
- **Fixed Point Iteration**
- **Newton-Raphson Method**

Users can type **any function**, choose a method, and see the iteration table,
convergence graph, and final root.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy for free (no credit card) — see full guide provided separately.
Quickest path: push this folder to a public GitHub repo, then deploy on
https://share.streamlit.io (Streamlit Community Cloud).
